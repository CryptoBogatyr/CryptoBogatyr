def hello_tea_xyz():
    print("Hi tea!")
